package poool.common.view;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import poool.common.model.Boundary;
import poool.common.model.Hole;
import poool.common.model.PooolModel;
import poool.common.model.PooolObserver;
import poool.common.controller.AController;

import java.util.List;

/**
 * View: it observes the model and,
 * on every update, copies the immutable snapshot into the {@link ViewModel}
 * and asks the frame to repaint.
 */
public class View implements PooolObserver {

    private final ViewModel viewModel;
    private final ViewFrame frame;

    public View(ViewModel viewModel, AController controller,
            Boundary bounds, List<Hole> holes, String mode) {
        this.viewModel = viewModel;
        this.frame = new ViewFrame(viewModel, controller, bounds, holes, mode);
    }

    public void display() {
        SwingUtilities.invokeLater(() -> frame.setVisible(true));
    }

    public JFrame getFrame() {
        return frame;
    }

    public void dispose() {
        try {
            SwingUtilities.invokeAndWait(frame::dispose);
        } catch (Exception ex) {
            frame.dispose();
        }
    }

    @Override
    public void modelUpdated(PooolModel model) {
        viewModel.update(model.getSnapshot());
        frame.refresh();
    }
}
